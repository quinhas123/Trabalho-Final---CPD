# Trabalho_Final_CPD

main --> preprocessing.py

Fase 1 - Check 

    HashPlayers - Check
    HashRatings - Check
    HashTags - Check
    Arvore Trie - Check

Tempo Fase 1 - 44,19 segundos //
No meu PC deu mais ou menos 30 segundos (não sei porque)

Fase 2 - X

    QuickSort - Check
    input - Não usado ainda
    Interface - X

Obs.: Tentei organizar em pastas mas o python não foi muito amigável com isso.
